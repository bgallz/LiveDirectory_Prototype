// Firebase configuration and load
var myFirebaseRef = new Firebase("https://incandescent-heat-7228.firebaseio.com");

// Use .child() as needed to listen for specific children of the root location
// e.g myFirebaseRef.child("staff");